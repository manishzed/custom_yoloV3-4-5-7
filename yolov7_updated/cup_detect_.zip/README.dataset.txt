# cup_detection > 2022-10-11 8:01pm
https://universe.roboflow.com/object-detection/cup_detection-egn6t

Provided by Roboflow
License: CC BY 4.0

